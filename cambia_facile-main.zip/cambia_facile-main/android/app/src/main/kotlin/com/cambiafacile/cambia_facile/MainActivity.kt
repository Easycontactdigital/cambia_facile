package com.cambiafacile.cambia_facile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
