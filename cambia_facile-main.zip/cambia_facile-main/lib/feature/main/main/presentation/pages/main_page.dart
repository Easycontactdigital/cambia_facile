import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:cambia_facile/core/config/router/app_router.dart';
import 'package:flutter/material.dart';

import '../../../../../core/config/app_strings.dart';

@RoutePage()
class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    return AutoTabsScaffold(
      routes: const [
        HomeRoute(),
        WalletRoute(),
        LinksRoute(),
      ],
      bottomNavigationBuilder: (context, tabsRouter) {
        return BottomNavigationBar(
          enableFeedback: true,
          currentIndex: tabsRouter.activeIndex,
          onTap: tabsRouter.setActiveIndex,
          selectedItemColor: AppColors.orange,
          elevation: 10,
          items: [
            BottomNavigationBarItem(
              icon: const Icon(Icons.home_filled),
              label: AppStrings.home,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.wallet),
              label: AppStrings.wallet,
            ),
            BottomNavigationBarItem(
              icon: const Icon(Icons.link),
              label: AppStrings.links,
            ),
            /*BottomNavigationBarItem(
              icon: const Icon(Icons.person),
              label: AppStrings.profile,
            ),*/
          ],
        );
      },
    );
  }
}
