import 'package:cambia_facile/core/utils/errors/failures.dart';
import 'package:dartz/dartz.dart';

abstract class FormRepository {
  Future<Either<FailureEntity, bool>> sendForm({
    required String phone,
    required String name,
    required String surname,
    required String email,
    String? provider,
  });
}
