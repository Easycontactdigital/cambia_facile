import 'package:cambia_facile/core/domain/use_cases/use_case.dart';
import 'package:cambia_facile/feature/home/domain/repositories/form_repository.dart';
import 'package:dartz/dartz.dart';

import '../../../../core/utils/errors/failures.dart';

class SendFormUseCase
    implements UseCase<Either<FailureEntity, bool>, SendFormParams> {
  final FormRepository _repository;

  SendFormUseCase(this._repository);

  @override
  Future<Either<FailureEntity, bool>> call(SendFormParams param) async {
    return await _repository.sendForm(
      name: param.name,
      surname: param.surname,
      phone: param.phone,
      email: param.email,
      provider: param.provider,
    );
  }
}

class SendFormParams {
  final String phone;
  final String name;
  final String surname;
  final String email;
  final String? provider;

  SendFormParams({
    required this.phone,
    required this.name,
    required this.surname,
    required this.email,
    this.provider,
  });
}
