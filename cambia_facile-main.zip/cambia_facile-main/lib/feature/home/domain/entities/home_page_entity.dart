import 'dart:ui';

import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'home_page_entity.freezed.dart';

@freezed
class HomePageEntity with _$HomePageEntity {
  const factory HomePageEntity({
    @Default([]) List<CardItemEntity> cardsList,
  }) = _HomePageEntity;
}

@freezed
class CardItemEntity with _$CardItemEntity {
  const factory CardItemEntity({
    @Default('') String title,
    @Default('') String asset,
    @Default([]) List<String> explanation,
    @Default(AppColors.yellow) Color color,
    @Default(OfferType.energy) OfferType type,
  }) = _CardItemEntity;
}

enum OfferType {
  energy,
  gas,
  energyAndGas,
  telephony,
}
