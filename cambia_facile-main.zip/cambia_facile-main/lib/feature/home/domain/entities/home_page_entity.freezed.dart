// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'home_page_entity.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$HomePageEntity {
  List<CardItemEntity> get cardsList => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $HomePageEntityCopyWith<HomePageEntity> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $HomePageEntityCopyWith<$Res> {
  factory $HomePageEntityCopyWith(
          HomePageEntity value, $Res Function(HomePageEntity) then) =
      _$HomePageEntityCopyWithImpl<$Res, HomePageEntity>;
  @useResult
  $Res call({List<CardItemEntity> cardsList});
}

/// @nodoc
class _$HomePageEntityCopyWithImpl<$Res, $Val extends HomePageEntity>
    implements $HomePageEntityCopyWith<$Res> {
  _$HomePageEntityCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? cardsList = null,
  }) {
    return _then(_value.copyWith(
      cardsList: null == cardsList
          ? _value.cardsList
          : cardsList // ignore: cast_nullable_to_non_nullable
              as List<CardItemEntity>,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_HomePageEntityCopyWith<$Res>
    implements $HomePageEntityCopyWith<$Res> {
  factory _$$_HomePageEntityCopyWith(
          _$_HomePageEntity value, $Res Function(_$_HomePageEntity) then) =
      __$$_HomePageEntityCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call({List<CardItemEntity> cardsList});
}

/// @nodoc
class __$$_HomePageEntityCopyWithImpl<$Res>
    extends _$HomePageEntityCopyWithImpl<$Res, _$_HomePageEntity>
    implements _$$_HomePageEntityCopyWith<$Res> {
  __$$_HomePageEntityCopyWithImpl(
      _$_HomePageEntity _value, $Res Function(_$_HomePageEntity) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? cardsList = null,
  }) {
    return _then(_$_HomePageEntity(
      cardsList: null == cardsList
          ? _value._cardsList
          : cardsList // ignore: cast_nullable_to_non_nullable
              as List<CardItemEntity>,
    ));
  }
}

/// @nodoc

class _$_HomePageEntity implements _HomePageEntity {
  const _$_HomePageEntity({final List<CardItemEntity> cardsList = const []})
      : _cardsList = cardsList;

  final List<CardItemEntity> _cardsList;
  @override
  @JsonKey()
  List<CardItemEntity> get cardsList {
    if (_cardsList is EqualUnmodifiableListView) return _cardsList;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_cardsList);
  }

  @override
  String toString() {
    return 'HomePageEntity(cardsList: $cardsList)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_HomePageEntity &&
            const DeepCollectionEquality()
                .equals(other._cardsList, _cardsList));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_cardsList));

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_HomePageEntityCopyWith<_$_HomePageEntity> get copyWith =>
      __$$_HomePageEntityCopyWithImpl<_$_HomePageEntity>(this, _$identity);
}

abstract class _HomePageEntity implements HomePageEntity {
  const factory _HomePageEntity({final List<CardItemEntity> cardsList}) =
      _$_HomePageEntity;

  @override
  List<CardItemEntity> get cardsList;
  @override
  @JsonKey(ignore: true)
  _$$_HomePageEntityCopyWith<_$_HomePageEntity> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$CardItemEntity {
  String get title => throw _privateConstructorUsedError;
  String get asset => throw _privateConstructorUsedError;
  List<String> get explanation => throw _privateConstructorUsedError;
  Color get color => throw _privateConstructorUsedError;
  OfferType get type => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CardItemEntityCopyWith<CardItemEntity> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CardItemEntityCopyWith<$Res> {
  factory $CardItemEntityCopyWith(
          CardItemEntity value, $Res Function(CardItemEntity) then) =
      _$CardItemEntityCopyWithImpl<$Res, CardItemEntity>;
  @useResult
  $Res call(
      {String title,
      String asset,
      List<String> explanation,
      Color color,
      OfferType type});
}

/// @nodoc
class _$CardItemEntityCopyWithImpl<$Res, $Val extends CardItemEntity>
    implements $CardItemEntityCopyWith<$Res> {
  _$CardItemEntityCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = null,
    Object? asset = null,
    Object? explanation = null,
    Object? color = null,
    Object? type = null,
  }) {
    return _then(_value.copyWith(
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      asset: null == asset
          ? _value.asset
          : asset // ignore: cast_nullable_to_non_nullable
              as String,
      explanation: null == explanation
          ? _value.explanation
          : explanation // ignore: cast_nullable_to_non_nullable
              as List<String>,
      color: null == color
          ? _value.color
          : color // ignore: cast_nullable_to_non_nullable
              as Color,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as OfferType,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_CardItemEntityCopyWith<$Res>
    implements $CardItemEntityCopyWith<$Res> {
  factory _$$_CardItemEntityCopyWith(
          _$_CardItemEntity value, $Res Function(_$_CardItemEntity) then) =
      __$$_CardItemEntityCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String title,
      String asset,
      List<String> explanation,
      Color color,
      OfferType type});
}

/// @nodoc
class __$$_CardItemEntityCopyWithImpl<$Res>
    extends _$CardItemEntityCopyWithImpl<$Res, _$_CardItemEntity>
    implements _$$_CardItemEntityCopyWith<$Res> {
  __$$_CardItemEntityCopyWithImpl(
      _$_CardItemEntity _value, $Res Function(_$_CardItemEntity) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? title = null,
    Object? asset = null,
    Object? explanation = null,
    Object? color = null,
    Object? type = null,
  }) {
    return _then(_$_CardItemEntity(
      title: null == title
          ? _value.title
          : title // ignore: cast_nullable_to_non_nullable
              as String,
      asset: null == asset
          ? _value.asset
          : asset // ignore: cast_nullable_to_non_nullable
              as String,
      explanation: null == explanation
          ? _value._explanation
          : explanation // ignore: cast_nullable_to_non_nullable
              as List<String>,
      color: null == color
          ? _value.color
          : color // ignore: cast_nullable_to_non_nullable
              as Color,
      type: null == type
          ? _value.type
          : type // ignore: cast_nullable_to_non_nullable
              as OfferType,
    ));
  }
}

/// @nodoc

class _$_CardItemEntity implements _CardItemEntity {
  const _$_CardItemEntity(
      {this.title = '',
      this.asset = '',
      final List<String> explanation = const [],
      this.color = AppColors.yellow,
      this.type = OfferType.energy})
      : _explanation = explanation;

  @override
  @JsonKey()
  final String title;
  @override
  @JsonKey()
  final String asset;
  final List<String> _explanation;
  @override
  @JsonKey()
  List<String> get explanation {
    if (_explanation is EqualUnmodifiableListView) return _explanation;
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_explanation);
  }

  @override
  @JsonKey()
  final Color color;
  @override
  @JsonKey()
  final OfferType type;

  @override
  String toString() {
    return 'CardItemEntity(title: $title, asset: $asset, explanation: $explanation, color: $color, type: $type)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_CardItemEntity &&
            (identical(other.title, title) || other.title == title) &&
            (identical(other.asset, asset) || other.asset == asset) &&
            const DeepCollectionEquality()
                .equals(other._explanation, _explanation) &&
            (identical(other.color, color) || other.color == color) &&
            (identical(other.type, type) || other.type == type));
  }

  @override
  int get hashCode => Object.hash(runtimeType, title, asset,
      const DeepCollectionEquality().hash(_explanation), color, type);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_CardItemEntityCopyWith<_$_CardItemEntity> get copyWith =>
      __$$_CardItemEntityCopyWithImpl<_$_CardItemEntity>(this, _$identity);
}

abstract class _CardItemEntity implements CardItemEntity {
  const factory _CardItemEntity(
      {final String title,
      final String asset,
      final List<String> explanation,
      final Color color,
      final OfferType type}) = _$_CardItemEntity;

  @override
  String get title;
  @override
  String get asset;
  @override
  List<String> get explanation;
  @override
  Color get color;
  @override
  OfferType get type;
  @override
  @JsonKey(ignore: true)
  _$$_CardItemEntityCopyWith<_$_CardItemEntity> get copyWith =>
      throw _privateConstructorUsedError;
}
