import 'package:bloc/bloc.dart';
import 'package:cambia_facile/core/config/app_assets.dart';
import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:cambia_facile/core/config/app_strings.dart';
import 'package:cambia_facile/feature/home/domain/entities/home_page_entity.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'home_cubit.freezed.dart';
part 'home_state.dart';

class HomeCubit extends Cubit<HomeState> {
  HomeCubit() : super(const HomeState.initial());

  void initData() {
    emit(
      HomeState.initial(
        pageEntity: HomePageEntity(
          cardsList: [
            CardItemEntity(
              title: 'Energia',
              asset: AppAssets.bulb,
              explanation: AppStrings.powerFormExplanation,
              color: AppColors.yellow,
              type: OfferType.energy,
            ),
            CardItemEntity(
              title: 'Gas',
              asset: AppAssets.flame,
              explanation: AppStrings.gasFormExplanation,
              color: AppColors.violet,
              type: OfferType.gas,
            ),
            CardItemEntity(
              title: 'Gas & Luce',
              asset: AppAssets.bulbAndFlame,
              explanation: AppStrings.powerAndGasFormExplanation,
              color: AppColors.green,
              type: OfferType.energyAndGas,
            ),
            CardItemEntity(
              title: 'Telefonia',
              asset: AppAssets.modem,
              explanation: AppStrings.internetFormExplanation,
              color: AppColors.lightBlue,
              type: OfferType.telephony,
            ),
          ],
        ),
      ),
    );
  }
}
