part of 'home_cubit.dart';

@freezed
class HomeState with _$HomeState {
  const factory HomeState.initial({
    @Default(HomePageEntity()) HomePageEntity pageEntity,
  }) = _Initial;
}
