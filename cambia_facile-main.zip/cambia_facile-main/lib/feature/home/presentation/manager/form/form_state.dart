part of 'form_cubit.dart';

@freezed
class MyFormState with _$MyFormState {
  const factory MyFormState.initial() = _Initial;
  const factory MyFormState.loading() = _Loading;
  const factory MyFormState.success() = _Success;
  const factory MyFormState.error() = _Error;
}
