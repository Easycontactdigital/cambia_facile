import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../../domain/use_cases/send_form_use_case.dart';

part 'form_cubit.freezed.dart';
part 'form_state.dart';

class FormCubit extends Cubit<MyFormState> {
  final SendFormUseCase sendFormUseCase;
  final TextEditingController nameTextController = TextEditingController();
  final TextEditingController surnameTextController = TextEditingController();
  final TextEditingController phoneTextController = TextEditingController();
  final TextEditingController mailTextController = TextEditingController();

  String? _actualProvider;

  FormCubit({
    required this.sendFormUseCase,
  }) : super(const MyFormState.initial());

  Future<void> sendInformation() async {
    emit(const MyFormState.loading());
    final result = await sendFormUseCase(
      SendFormParams(
        phone: phoneTextController.text,
        name: nameTextController.text,
        surname: surnameTextController.text,
        email: mailTextController.text,
        provider: _actualProvider,
      ),
    );

    result.fold(
      (error) => emit(const MyFormState.error()),
      (sent) => emit(const MyFormState.success()),
    );
  }

  void updateActualProvider({
    required String? provider,
  }) {
    _actualProvider = provider;
  }

  void clear() {
    nameTextController.clear();
    surnameTextController.clear();
    phoneTextController.clear();
    mailTextController.clear();
    _actualProvider = null;
  }
}
