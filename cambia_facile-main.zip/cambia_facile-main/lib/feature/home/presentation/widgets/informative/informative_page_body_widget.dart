import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/config/app_constants.dart';
import 'package:cambia_facile/core/config/app_strings.dart';
import 'package:cambia_facile/feature/home/domain/entities/home_page_entity.dart';
import 'package:cambia_facile/feature/home/presentation/widgets/informative/informative_page_more_information_widget.dart';
import 'package:flutter/material.dart';

import '../../../../../core/config/app_assets.dart';
import '../../../../../core/config/app_colors.dart';
import '../../../../../core/config/app_fonts.dart';
import '../../../../../core/config/router/app_router.dart';
import '../../../../../core/presentation/widgets/chip_number_and_text_widget.dart';

class InformativePageBodyWidget extends StatelessWidget {
  final String title;
  final List<String> explanation;
  final OfferType offerType;

  const InformativePageBodyWidget({
    super.key,
    required this.title,
    required this.explanation,
    required this.offerType,
  });

  @override
  Widget build(BuildContext context) {
    List<String> informativeTexts = AppStrings.informativeTexts;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Image.asset(
              AppAssets.informative,
              height: 300,
            ),
            const SizedBox(height: 24),
            ListView.separated(
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return ChipNumberAndTextWidget(
                  index: index,
                  text: informativeTexts[index],
                );
              },
              itemCount: informativeTexts.length,
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(
                  height: 8,
                );
              },
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () async {
                context.router.replace(FormRoute(
                  title: title,
                  explanation: explanation,
                  offerType: offerType,
                ));
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.orange,
                minimumSize: const Size(double.infinity, 40),
              ),
              child: Text(
                AppStrings.proceed,
                style: const TextStyle(
                  fontSize: 20,
                  fontFamily: AppFonts.robotoRegular,
                ),
              ),
            ),
            const SizedBox(height: 24),
            InformativePageMoreInformationWidget(
              title: offerType == OfferType.telephony
                  ? AppStrings.bestInternetOfferTitle
                  : AppStrings.howToSaveMoneyForEnergyAndGasTitle,
              message: offerType == OfferType.telephony
                  ? AppStrings.bestInternetOfferMessage
                  : AppStrings.howToSaveMoneyForEnergyAndGasMessage,
              images: offerType == OfferType.telephony
                  ? AppConstants.internetProvidersHandledImages
                  : AppConstants.energyAndGasProvidersHandledImages,
            ),
          ],
        ),
      ),
    );
  }
}
