import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:cambia_facile/core/config/app_fonts.dart';
import 'package:cambia_facile/core/config/app_strings.dart';
import 'package:flutter/material.dart';

class InformativePageMoreInformationWidget extends StatelessWidget {
  final List<String> images;
  final String title;
  final String message;

  const InformativePageMoreInformationWidget({
    Key? key,
    required this.images,
    required this.title,
    required this.message,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          title,
          style: const TextStyle(
            fontFamily: AppFonts.robotoBold,
            color: AppColors.orange,
            fontSize: 20,
          ),
        ),
        const SizedBox(height: 12),
        Text(
          message,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontFamily: AppFonts.robotoRegular,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 24),
        Text(
          AppStrings.someProviders,
          style: const TextStyle(
            fontFamily: AppFonts.robotoBold,
            color: AppColors.orange,
            fontSize: 20,
          ),
        ),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (context, index) {
            return Image.asset(
              images[index],
            );
          },
          itemCount: images.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 2,
            crossAxisSpacing: 30,
            mainAxisSpacing: 30,
          ),
        ),
      ],
    );
  }
}
