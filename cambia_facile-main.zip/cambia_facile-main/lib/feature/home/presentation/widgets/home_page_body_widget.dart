import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/config/app_assets.dart';
import 'package:cambia_facile/core/config/app_fonts.dart';
import 'package:cambia_facile/core/config/di/provider.dart';
import 'package:cambia_facile/core/config/router/app_router.dart';
import 'package:cambia_facile/feature/home/presentation/manager/home_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../../../core/config/app_strings.dart';

class HomePageBodyWidget extends StatelessWidget {
  const HomePageBodyWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<HomeCubit, HomeState>(
      bloc: injector<HomeCubit>()..initData(),
      builder: (context, state) {
        return SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Image.asset(
                  AppAssets.logoWithName,
                  height: 60,
                ),
              ),
              const SizedBox(height: 24),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Text(
                  AppStrings.saveMoney,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    fontFamily: AppFonts.robotoBold,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              ListView.separated(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                padding: const EdgeInsets.all(16),
                itemBuilder: (context, index) {
                  var cardItemEntity = state.pageEntity.cardsList[index];
                  return InkWell(
                    onTap: () => context.router.push(
                      InformativeRoute(
                        title: cardItemEntity.title,
                        explanation: cardItemEntity.explanation,
                        offerType: cardItemEntity.type,
                      ),
                    ),
                    child: Card(
                      borderOnForeground: true,
                      shape: RoundedRectangleBorder(
                        side: BorderSide(
                          color: cardItemEntity.color.withOpacity(0.5),
                          style: BorderStyle.solid,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(25),
                        ),
                      ),
                      elevation: 2,
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            SvgPicture.asset(
                              cardItemEntity.asset,
                              height: 50,
                            ),
                            const SizedBox(
                              width: 12,
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    AppStrings.sale,
                                    style: const TextStyle(
                                      fontFamily: AppFonts.robotoRegular,
                                      color: Colors.lightBlueAccent,
                                      fontSize: 11,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    cardItemEntity.title,
                                    style: const TextStyle(
                                      fontFamily: AppFonts.robotoBold,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
                separatorBuilder: (context, index) {
                  return const SizedBox(
                    height: 16,
                  );
                },
                itemCount: state.pageEntity.cardsList.length,
              ),
            ],
          ),
        );
      },
    );
  }
}
