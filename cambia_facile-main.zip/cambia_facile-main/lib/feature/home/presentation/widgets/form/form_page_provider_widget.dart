import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:cambia_facile/core/config/app_constants.dart';
import 'package:cambia_facile/core/config/app_strings.dart';
import 'package:cambia_facile/core/config/di/provider.dart';
import 'package:cambia_facile/feature/home/presentation/manager/form/form_cubit.dart';
import 'package:flutter/material.dart';

import '../../../../../core/config/app_fonts.dart';
import '../../../domain/entities/home_page_entity.dart';

class FormPageProviderWidget extends StatefulWidget {
  final OfferType offerType;

  const FormPageProviderWidget({
    Key? key,
    required this.offerType,
  }) : super(key: key);

  @override
  State<FormPageProviderWidget> createState() => _FormPageProviderWidgetState();
}

class _FormPageProviderWidgetState extends State<FormPageProviderWidget> {
  bool _isProviderListVisible = false;
  int _providerSelected = -1;

  @override
  Widget build(BuildContext context) {
    switch (widget.offerType) {
      case OfferType.telephony:
        return const SizedBox.shrink();
      default:
        return Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    AppStrings.doYouRememberProvider,
                    style: const TextStyle(
                      fontFamily: AppFonts.robotoRegular,
                      fontSize: 16,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Switch(
                  value: _isProviderListVisible,
                  onChanged: (value) => setState(() {
                    if (!value) {
                      _providerSelected = -1;
                      injector<FormCubit>().updateActualProvider(
                        provider: null,
                      );
                    }
                    _isProviderListVisible = value;
                  }),
                  trackColor: MaterialStateProperty.resolveWith<Color?>(
                    (Set<MaterialState> states) {
                      if (states.contains(MaterialState.selected)) {
                        return AppColors.orange.withOpacity(0.3);
                      }
                      if (states.contains(MaterialState.disabled)) {
                        return Colors.grey.shade400;
                      }
                      return null;
                    },
                  ),
                  thumbColor: MaterialStateProperty.resolveWith<Color?>(
                    (Set<MaterialState> states) {
                      if (states.contains(MaterialState.selected)) {
                        return AppColors.orange;
                      }
                      if (states.contains(MaterialState.disabled)) {
                        return Colors.grey.shade400;
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
            Visibility(
              visible: _isProviderListVisible,
              child: GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      injector<FormCubit>().updateActualProvider(
                        provider: AppConstants.energyAndGasProviders[index].$1,
                      );

                      setState(() {
                        _providerSelected = index;
                      });
                    },
                    child: Container(
                      margin: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: AppColors.orange.withOpacity(0.1),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(20),
                        ),
                        border: Border.all(
                          color: AppColors.orange,
                          width: (_providerSelected == index) ? 3 : 0,
                        ),
                      ),
                      child: Column(
                        children: [
                          Image.asset(
                            AppConstants.energyAndGasProviders[index].$2,
                            height: 100,
                            width: 100,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  AppConstants.energyAndGasProviders[index].$1,
                                  textAlign: TextAlign.center,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontFamily: AppFonts.robotoBold,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
                itemCount: AppConstants.energyAndGasProviders.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                ),
              ),
            ),
          ],
        );
    }
  }
}
