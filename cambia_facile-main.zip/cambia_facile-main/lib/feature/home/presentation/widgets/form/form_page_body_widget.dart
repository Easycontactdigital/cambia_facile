import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:cambia_facile/core/config/app_extensions.dart';
import 'package:cambia_facile/core/config/app_strings.dart';
import 'package:cambia_facile/core/config/di/provider.dart';
import 'package:cambia_facile/core/presentation/widgets/chip_number_and_text_widget.dart';
import 'package:cambia_facile/feature/home/presentation/widgets/form/form_page_provider_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import '../../../../../core/config/app_fonts.dart';
import '../../../domain/entities/home_page_entity.dart';
import '../../manager/form/form_cubit.dart';

class FormPageBodyWidget extends StatefulWidget {
  final List<String> explanationPoints;
  final OfferType offerType;

  const FormPageBodyWidget({
    super.key,
    required this.explanationPoints,
    required this.offerType,
  });

  @override
  State<FormPageBodyWidget> createState() => _FormPageBodyWidgetState();
}

class _FormPageBodyWidgetState extends State<FormPageBodyWidget> {
  final _formKey = GlobalKey<FormState>();

  String? _fieldValidator(String? value, {bool? email, bool? phoneNumber}) {
    if (value == null || value.isEmpty) {
      return AppStrings.mandatoryField;
    }

    if (email ?? false) {
      if (!value.isValidEmail()) {
        return AppStrings.insertValidEmail;
      }
    }

    if (phoneNumber ?? false) {
      if (!value.isValidPhoneNumber()) {
        return AppStrings.insertValidPhone;
      }
    }

    return null;
  }

  InputBorder focusedBorder() {
    return const UnderlineInputBorder(
      borderSide: BorderSide(color: AppColors.orange),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<FormCubit, MyFormState>(
      bloc: injector<FormCubit>(),
      listener: (context, state) {
        state.maybeMap(
          orElse: () => EasyLoading.dismiss(),
          loading: (_) => EasyLoading.show(),
          success: (_) async {
            injector<FormCubit>().clear();
            await EasyLoading.showSuccess(
              AppStrings.successMessage,
              duration: const Duration(seconds: 3),
            ).then((value) => context.router.pop());
          },
          error: (_) => EasyLoading.showError(
            AppStrings.failureMessage,
            duration: const Duration(seconds: 3),
          ),
        );
      },
      builder: (context, state) {
        return SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              children: [
                ListView.separated(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return ChipNumberAndTextWidget(
                      index: index,
                      text: widget.explanationPoints[index],
                    );
                  },
                  itemCount: widget.explanationPoints.length,
                  separatorBuilder: (BuildContext context, int index) {
                    return const SizedBox(
                      height: 8,
                    );
                  },
                ),
                const SizedBox(height: 20),
                Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: [
                      TextFormField(
                        autofocus: true,
                        controller: injector<FormCubit>().nameTextController,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        keyboardType: TextInputType.name,
                        cursorColor: AppColors.orange,
                        validator: (value) => _fieldValidator(value),
                        decoration: InputDecoration(
                          hintText: AppStrings.name,
                          focusedBorder: focusedBorder(),
                          hintStyle: const TextStyle(
                            fontFamily: AppFonts.robotoRegular,
                          ),
                        ),
                        style: const TextStyle(
                          fontFamily: AppFonts.robotoRegular,
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        controller: injector<FormCubit>().surnameTextController,
                        keyboardType: TextInputType.name,
                        cursorColor: AppColors.orange,
                        validator: (value) => _fieldValidator(value),
                        decoration: InputDecoration(
                          hintText: AppStrings.surname,
                          focusedBorder: focusedBorder(),
                          hintStyle: const TextStyle(
                            fontFamily: AppFonts.robotoRegular,
                          ),
                        ),
                        style: const TextStyle(
                          fontFamily: AppFonts.robotoRegular,
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: injector<FormCubit>().mailTextController,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        keyboardType: TextInputType.emailAddress,
                        cursorColor: AppColors.orange,
                        validator: (value) =>
                            _fieldValidator(value, email: true),
                        decoration: InputDecoration(
                          hintText: (AppStrings.email),
                          focusedBorder: focusedBorder(),
                          hintStyle: const TextStyle(
                            fontFamily: AppFonts.robotoRegular,
                          ),
                        ),
                        style: const TextStyle(
                          fontFamily: AppFonts.robotoRegular,
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: injector<FormCubit>().phoneTextController,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        keyboardType: TextInputType.phone,
                        cursorColor: AppColors.orange,
                        validator: (value) => _fieldValidator(
                          value,
                          phoneNumber: true,
                        ),
                        decoration: InputDecoration(
                          hintText: (AppStrings.phoneNumber),
                          focusedBorder: focusedBorder(),
                          hintStyle: const TextStyle(
                            fontFamily: AppFonts.robotoRegular,
                          ),
                        ),
                        style: const TextStyle(
                          fontFamily: AppFonts.robotoRegular,
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      FormPageProviderWidget(
                        offerType: widget.offerType,
                      ),
                      const SizedBox(height: 40),
                      ElevatedButton(
                        onPressed: () async {
                          if (_formKey.currentState?.validate() ?? false) {
                            await injector<FormCubit>().sendInformation();
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.orange,
                          minimumSize: const Size(double.infinity, 40),
                        ),
                        child: Text(
                          AppStrings.send,
                          style: const TextStyle(
                            fontSize: 20,
                            fontFamily: AppFonts.robotoRegular,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
