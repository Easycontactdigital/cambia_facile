import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/feature/home/domain/entities/home_page_entity.dart';
import 'package:flutter/material.dart';

import '../../../../../core/config/app_colors.dart';
import '../../../../../core/presentation/pages/app_base_page.dart';
import '../../widgets/informative/informative_page_body_widget.dart';

@RoutePage()
class InformativePage extends StatelessWidget {
  final String title;
  final List<String> explanation;
  final OfferType offerType;

  const InformativePage({
    super.key,
    required this.title,
    required this.explanation,
    required this.offerType,
  });

  @override
  Widget build(BuildContext context) {
    return AppBasePage(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () {
            context.router.pop();
          },
          child: const Icon(
            Icons.arrow_back_ios,
            color: AppColors.orange,
          ),
        ),
        elevation: 1,
        title: Text(title),
        backgroundColor: Colors.white,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
        ),
        foregroundColor: AppColors.orange,
      ),
      body: InformativePageBodyWidget(
        title: title,
        explanation: explanation,
        offerType: offerType,
      ),
    );
  }
}
