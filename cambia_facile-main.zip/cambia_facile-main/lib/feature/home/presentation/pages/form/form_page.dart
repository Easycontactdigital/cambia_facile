import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:cambia_facile/core/presentation/pages/app_base_page.dart';
import 'package:cambia_facile/feature/home/domain/entities/home_page_entity.dart';
import 'package:cambia_facile/feature/home/presentation/widgets/form/form_page_body_widget.dart';
import 'package:flutter/material.dart';

import '../../../../../core/config/di/provider.dart';
import '../../manager/form/form_cubit.dart';

@RoutePage()
class FormPage extends StatelessWidget {
  final String title;
  final List<String> explanation;
  final OfferType offerType;

  const FormPage({
    super.key,
    required this.title,
    required this.explanation,
    required this.offerType,
  });

  @override
  Widget build(BuildContext context) {
    return AppBasePage(
      appBar: AppBar(
        leading: GestureDetector(
          onTap: () {
            injector<FormCubit>().clear();
            context.router.pop();
          },
          child: const Icon(
            Icons.arrow_back_ios,
            color: AppColors.orange,
          ),
        ),
        elevation: 1,
        title: Text(title),
        backgroundColor: Colors.white,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
        ),
        foregroundColor: AppColors.orange,
      ),
      body: FormPageBodyWidget(
        explanationPoints: explanation,
        offerType: offerType,
      ),
    );
  }
}
