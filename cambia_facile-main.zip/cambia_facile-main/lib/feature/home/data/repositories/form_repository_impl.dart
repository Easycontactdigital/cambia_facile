import 'package:cambia_facile/core/utils/errors/failures.dart';
import 'package:cambia_facile/feature/home/data/data_source/remote/from_remote_data_source.dart';
import 'package:cambia_facile/feature/home/domain/repositories/form_repository.dart';
import 'package:dartz/dartz.dart';

class FormRepositoryImpl extends FormRepository {
  final FormRemoteDataSource _remoteDataSource;

  FormRepositoryImpl(this._remoteDataSource);

  @override
  Future<Either<FailureEntity, bool>> sendForm({
    required String phone,
    required String name,
    required String surname,
    required String email,
    String? provider,
  }) async {
    return await _remoteDataSource.sendForm(
      phone: phone,
      name: name,
      surname: surname,
      email: email,
      provider: provider,
    );
  }
}
