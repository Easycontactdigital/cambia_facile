import 'package:cambia_facile/core/config/app_enpoint.dart';
import 'package:cambia_facile/core/utils/errors/failures.dart';
import 'package:cambia_facile/feature/home/data/data_source/remote/from_remote_data_source.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

class FormRemoteDataSourceImpl extends FormRemoteDataSource {
  final Dio _dioClient;

  FormRemoteDataSourceImpl(this._dioClient);

  @override
  Future<Either<FailureEntity, bool>> sendForm({
    required String phone,
    required String name,
    required String surname,
    required String email,
    String? provider,
  }) async {
    try {
      final response = await _dioClient.post(
        AppEndpoint.sendFormEndpoint,
        queryParameters: {
          'phone1': phone,
          'surname': surname,
          'name': name,
          'email': email,
          'custom1': provider,
        },
      );

      if (response.data is String || response.data.isDefinedAndNotNull) {
        return right(true);
      }

      return left(const FailureEntity.serverFailure());
    } on DioException catch (e, stacktrace) {
      debugPrintStack(stackTrace: stacktrace);
      return left(const FailureEntity.serverFailure());
    } catch (e, stacktrace) {
      debugPrintStack(stackTrace: stacktrace);
      return left(const FailureEntity.serverFailure());
    }
  }
}
