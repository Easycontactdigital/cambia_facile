import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/presentation/pages/app_base_page.dart';
import 'package:cambia_facile/feature/links/presentation/widgets/links_page_body_widget.dart';
import 'package:flutter/cupertino.dart';

@RoutePage()
class LinksPage extends StatelessWidget {
  const LinksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppBasePage(
      body: LinksPageBodyWidget(),
    );
  }
}
