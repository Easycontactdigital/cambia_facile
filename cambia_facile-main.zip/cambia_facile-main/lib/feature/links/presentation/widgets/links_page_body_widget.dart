import 'package:cambia_facile/core/config/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../core/config/app_assets.dart';
import '../../../../core/config/app_fonts.dart';
import '../../../../core/config/app_strings.dart';

class LinksPageBodyWidget extends StatelessWidget {
  const LinksPageBodyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          children: [
            const SizedBox(height: 24),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Image.asset(
                AppAssets.logoWithName,
                height: 60,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              AppStrings.contactInformation,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 20,
                fontFamily: AppFonts.robotoThin,
              ),
            ),
            const SizedBox(height: 12),
            _buildItemCardWidget(
              '390283623353',
              'Chiamaci!',
              Icons.phone,
              AppColors.green,
              Uri(scheme: 'tel', path: '390283623353'),
            ),
            const SizedBox(height: 12),
            _buildItemCardWidget(
              'www.cambiafacile.it',
              'Vienici a trovare!',
              Icons.web,
              AppColors.violet,
              Uri(scheme: 'https', path: 'www.cambiafacile.it'),
            ),
            const SizedBox(height: 12),
            _buildItemCardWidget(
              'info@cambiafacile.it',
              'Inviaci un email!',
              Icons.alternate_email,
              AppColors.lightBlue,
              Uri(scheme: 'mailto', path: 'info@cambiafacile.it'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildItemCardWidget(
    String text,
    String subText,
    IconData icon,
    Color color,
    Uri uri,
  ) {
    return InkWell(
      onTap: () async {
        if (await canLaunchUrl(uri)) {
          await launchUrl(uri, mode: LaunchMode.externalApplication);
        }
      },
      child: Card(
        borderOnForeground: true,
        shape: RoundedRectangleBorder(
          side: BorderSide(
            color: color.withOpacity(0.5),
            style: BorderStyle.solid,
          ),
          borderRadius: const BorderRadius.all(
            Radius.circular(25),
          ),
        ),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 20.0,
            horizontal: 12,
          ),
          child: Row(
            children: [
              Icon(
                icon,
                color: color,
              ),
              const SizedBox(
                width: 12,
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      text,
                      style: const TextStyle(
                        fontFamily: AppFonts.robotoMedium,
                        fontSize: 18,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      subText,
                      style: TextStyle(
                        fontFamily: AppFonts.robotoLight,
                        fontSize: 14,
                        color: color,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
