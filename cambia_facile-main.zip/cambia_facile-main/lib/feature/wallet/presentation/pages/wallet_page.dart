import 'package:auto_route/annotations.dart';
import 'package:cambia_facile/core/presentation/pages/app_base_page.dart';
import 'package:cambia_facile/feature/wallet/presentation/widgets/wallet_page_body_widget.dart';
import 'package:flutter/cupertino.dart';

@RoutePage()
class WalletPage extends StatelessWidget {
  const WalletPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const AppBasePage(
      body: WalletPageBodyWidget(),
    );
  }
}
