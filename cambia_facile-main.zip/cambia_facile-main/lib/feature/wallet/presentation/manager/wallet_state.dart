part of 'wallet_cubit.dart';

@freezed
class WalletState with _$WalletState {
  const factory WalletState.initial() = _Initial;

  const factory WalletState.loading() = _Loading;

  const factory WalletState.error() = _Error;

  const factory WalletState.loaded({
    @Default([]) List<UserRequestDetailEntity> userRequests,
  }) = _Loaded;
}
