import 'package:bloc/bloc.dart';
import 'package:flutter/cupertino.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

import '../../domain/entities/user_request_detail_entity.dart';
import '../../domain/use_cases/get_user_requests_use_case.dart';

part 'wallet_cubit.freezed.dart';
part 'wallet_state.dart';

class WalletCubit extends Cubit<WalletState> {
  final GetUserRequestsUseCase getUserRequestsUseCase;
  final TextEditingController requestIdController = TextEditingController();

  WalletCubit({
    required this.getUserRequestsUseCase,
  }) : super(const WalletState.initial());

  Future<void> getUserRequests() async {
    emit(const WalletState.loading());

    final getUserRequestsResult = await getUserRequestsUseCase.call(
      requestIdController.text,
    );

    getUserRequestsResult.fold(
      (error) => emit(const WalletState.error()),
      (userRequests) => emit(WalletState.loaded(
        userRequests: userRequests,
      )),
    );
  }
}
