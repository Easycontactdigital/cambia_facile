import 'package:cambia_facile/core/config/app_extensions.dart';
import 'package:cambia_facile/core/config/app_strings.dart';
import 'package:cambia_facile/core/config/di/provider.dart';
import 'package:cambia_facile/feature/wallet/presentation/manager/wallet_cubit.dart';
import 'package:cambia_facile/feature/wallet/presentation/widgets/wallet_page_body_empty_request_widget.dart';
import 'package:cambia_facile/feature/wallet/presentation/widgets/wallet_page_body_request_list_widget.dart';
import 'package:cambia_facile/feature/wallet/presentation/widgets/wallet_page_body_search_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import '../../../../core/config/app_assets.dart';
import '../../../../core/config/app_colors.dart';
import '../../../../core/config/app_fonts.dart';
import '../../domain/entities/user_request_detail_entity.dart';

class WalletPageBodyWidget extends StatefulWidget {
  const WalletPageBodyWidget({Key? key}) : super(key: key);

  @override
  State<WalletPageBodyWidget> createState() => _WalletPageBodyWidgetState();
}

class _WalletPageBodyWidgetState extends State<WalletPageBodyWidget> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return BlocConsumer<WalletCubit, WalletState>(
      bloc: injector<WalletCubit>(),
      builder: (context, state) {
        bool showList = state.maybeWhen(
          orElse: () => false,
          loaded: (userRequests) => userRequests.isNotEmpty,
        );

        List<UserRequestDetailEntity> userRequests = state.maybeWhen(
          orElse: () => [],
          loaded: (userRequests) => userRequests,
        );

        return SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const SizedBox(height: 24),
              Image.asset(
                width: double.infinity,
                AppAssets.logoWithName,
                height: 60,
              ),
              const SizedBox(height: 24),
              const WalletPageBodySearchWidget(),
              const SizedBox(height: 24),
              Row(
                children: [
                  Text(
                    AppStrings.yourRequests,
                    style: const TextStyle(
                      fontSize: 20,
                      fontFamily: AppFonts.robotoBold,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ],
              ),
              const SizedBox(height: 24),
              Visibility(
                visible: !showList,
                child: const WalletPageBodyEmptyRequestWidget(),
              ),
              Visibility(
                visible: showList,
                child: WalletPageBodyRequestListWidget(
                  userRequest: userRequests,
                ),
              )
            ],
          ),
        );
      },
      listener: (context, state) {
        state.maybeWhen(
          orElse: () => EasyLoading.dismiss(),
          loading: () => EasyLoading.show(),
          error: () => EasyLoading.showError(
            AppStrings.failureMessage,
            duration: const Duration(seconds: 3),
          ),
        );
      },
    );
  }

  String? _fieldValidator(String? value, {bool? email, bool? phoneNumber}) {
    if (value == null || value.isEmpty) {
      return AppStrings.mandatoryField;
    }

    if (email ?? false) {
      if (!value.isValidEmail()) {
        return AppStrings.insertValidEmail;
      }
    }

    if (phoneNumber ?? false) {
      if (!value.isValidPhoneNumber()) {
        return AppStrings.insertValidPhone;
      }
    }

    return null;
  }

  InputBorder focusedBorder() {
    return const UnderlineInputBorder(
      borderSide: BorderSide(color: AppColors.orange),
    );
  }
}
