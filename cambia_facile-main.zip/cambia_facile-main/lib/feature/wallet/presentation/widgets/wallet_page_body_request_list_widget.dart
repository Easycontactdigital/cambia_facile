import 'package:cambia_facile/feature/wallet/presentation/widgets/request_item_widget.dart';
import 'package:flutter/material.dart';

import '../../domain/entities/user_request_detail_entity.dart';

class WalletPageBodyRequestListWidget extends StatelessWidget {
  final List<UserRequestDetailEntity> userRequest;

  const WalletPageBodyRequestListWidget({
    Key? key,
    required this.userRequest,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemBuilder: (context, index) {
        return RequestItemWidget(
          name: userRequest[index].name,
          surname: userRequest[index].surname,
          phoneNumber: userRequest[index].phone,
          requestType: userRequest[index].productId,
          creationDate: userRequest[index].creationDate,
          status: userRequest[index].status,
        );
      },
      separatorBuilder: (context, index) => const SizedBox(
        height: 12,
      ),
      itemCount: userRequest.length,
    );
  }
}
