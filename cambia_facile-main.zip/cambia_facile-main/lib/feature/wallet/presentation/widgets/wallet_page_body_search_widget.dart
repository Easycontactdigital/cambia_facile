import 'package:cambia_facile/core/config/app_extensions.dart';
import 'package:flutter/material.dart';

import '../../../../core/config/app_colors.dart';
import '../../../../core/config/app_fonts.dart';
import '../../../../core/config/app_strings.dart';
import '../../../../core/config/di/provider.dart';
import '../manager/wallet_cubit.dart';

class WalletPageBodySearchWidget extends StatefulWidget {
  const WalletPageBodySearchWidget({super.key});

  @override
  State<WalletPageBodySearchWidget> createState() =>
      _WalletPageBodySearchWidgetState();
}

class _WalletPageBodySearchWidgetState
    extends State<WalletPageBodySearchWidget> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      initiallyExpanded: false,
      iconColor: AppColors.orange,
      collapsedBackgroundColor: Colors.white,
      collapsedIconColor: AppColors.orange,
      backgroundColor: Colors.white,
      textColor: Colors.black,
      childrenPadding: const EdgeInsets.all(12),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(20),
        ),
      ),
      collapsedShape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(20),
        ),
      ),
      title: const Text('Cerca'),
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.all(
              Radius.circular(4),
            ),
            border: Border.all(
              color: AppColors.orange,
              width: 1,
              style: BorderStyle.solid,
            ),
          ),
          child: Text(
            AppStrings.walletExplanation,
            style: const TextStyle(
              fontSize: 13,
              fontFamily: AppFonts.robotoBold,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 12),
        Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                autofocus: true,
                controller: injector<WalletCubit>().requestIdController,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                cursorColor: AppColors.orange,
                validator: (value) => _fieldValidator(
                  value,
                ),
                decoration: InputDecoration(
                  hintText: AppStrings.requstId,
                  focusedBorder: focusedBorder(),
                  hintStyle: const TextStyle(
                    fontFamily: AppFonts.robotoRegular,
                  ),
                ),
                style: const TextStyle(
                  fontFamily: AppFonts.robotoRegular,
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState?.validate() ?? false) {
                    await injector<WalletCubit>().getUserRequests();
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.orange,
                  minimumSize: const Size(double.infinity, 40),
                ),
                child: Text(
                  AppStrings.search,
                  style: const TextStyle(
                    fontSize: 20,
                    fontFamily: AppFonts.robotoRegular,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.all(
              Radius.circular(4),
            ),
            border: Border.all(
              color: AppColors.orange,
              width: 1,
              style: BorderStyle.solid,
            ),
          ),
          child: Text(
            AppStrings.walletExplanation,
            style: const TextStyle(
              fontSize: 13,
              fontFamily: AppFonts.robotoBold,
            ),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 12),
        Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                autofocus: true,
                controller: injector<WalletCubit>().requestIdController,
                autovalidateMode: AutovalidateMode.onUserInteraction,
                cursorColor: AppColors.orange,
                validator: (value) => _fieldValidator(
                  value,
                ),
                decoration: InputDecoration(
                  hintText: AppStrings.requstId,
                  focusedBorder: focusedBorder(),
                  hintStyle: const TextStyle(
                    fontFamily: AppFonts.robotoRegular,
                  ),
                ),
                style: const TextStyle(
                  fontFamily: AppFonts.robotoRegular,
                ),
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState?.validate() ?? false) {
                    await injector<WalletCubit>().getUserRequests();
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.orange,
                  minimumSize: const Size(double.infinity, 40),
                ),
                child: Text(
                  AppStrings.search,
                  style: const TextStyle(
                    fontSize: 20,
                    fontFamily: AppFonts.robotoRegular,
                  ),
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  String? _fieldValidator(String? value, {bool? email, bool? phoneNumber}) {
    if (value == null || value.isEmpty) {
      return AppStrings.mandatoryField;
    }

    if (email ?? false) {
      if (!value.isValidEmail()) {
        return AppStrings.insertValidEmail;
      }
    }

    if (phoneNumber ?? false) {
      if (!value.isValidPhoneNumber()) {
        return AppStrings.insertValidPhone;
      }
    }

    return null;
  }

  InputBorder focusedBorder() {
    return const UnderlineInputBorder(
      borderSide: BorderSide(color: AppColors.orange),
    );
  }
}
