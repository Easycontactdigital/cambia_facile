import 'package:flutter/material.dart';

import '../../../../core/config/app_fonts.dart';
import '../../../../core/config/app_strings.dart';

class RequestItemWidget extends StatelessWidget {
  final String name;
  final String surname;
  final String status;
  final String phoneNumber;
  final String requestType;
  final String creationDate;

  const RequestItemWidget({
    Key? key,
    required this.name,
    required this.surname,
    required this.status,
    required this.phoneNumber,
    required this.requestType,
    required this.creationDate,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      borderOnForeground: true,
      shape: const RoundedRectangleBorder(
        side: BorderSide(
          color: Colors.white38,
          style: BorderStyle.solid,
        ),
        borderRadius: BorderRadius.all(
          Radius.circular(14),
        ),
      ),
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    AppStrings.contactsInformation.toUpperCase(),
                    style: const TextStyle(
                      fontFamily: AppFonts.robotoRegular,
                      color: Colors.lightBlueAccent,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildTitleSubTitleText(
                    subTitle: 'Nome',
                    title: name.length > 3
                        ? name.replaceRange(
                            3,
                            null,
                            '*'.padRight(name.length - 3, '*'),
                          )
                        : name,
                  ),
                  _buildTitleSubTitleText(
                    subTitle: 'Congonme',
                    title: surname.length > 2
                        ? surname.replaceRange(
                            2,
                            null,
                            '*'.padRight(surname.length - 2, '*'),
                          )
                        : surname,
                  ),
                  _buildTitleSubTitleText(
                    subTitle: 'Numero di telefono',
                    title: phoneNumber.length > 9
                        ? phoneNumber.replaceRange(
                            0,
                            phoneNumber.length - 3,
                            '*******',
                          )
                        : phoneNumber,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    AppStrings.requestInformation.toUpperCase(),
                    style: const TextStyle(
                      fontFamily: AppFonts.robotoRegular,
                      color: Colors.lightBlueAccent,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _buildTitleSubTitleText(
                    subTitle: 'Prodotto',
                    title: requestType,
                  ),
                  _buildTitleSubTitleText(
                    subTitle: 'Data creazione',
                    title: creationDate,
                  ),
                  _buildTitleSubTitleText(
                    subTitle: 'Stato',
                    title: status,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTitleSubTitleText({
    required String subTitle,
    required String title,
  }) {
    return Text.rich(
      TextSpan(
        text: '$subTitle: ',
        style: const TextStyle(
          fontFamily: AppFonts.robotoBold,
          fontWeight: FontWeight.w700,
          fontSize: 12,
          color: Colors.grey,
        ),
        children: [
          TextSpan(
            text: title,
            style: const TextStyle(
              fontFamily: AppFonts.robotoBold,
              fontWeight: FontWeight.w700,
              fontSize: 12,
              color: Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}
