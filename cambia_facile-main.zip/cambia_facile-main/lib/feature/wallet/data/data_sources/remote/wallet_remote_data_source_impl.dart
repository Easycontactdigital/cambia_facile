import 'dart:convert';

import 'package:cambia_facile/core/utils/errors/failures.dart';
import 'package:cambia_facile/feature/wallet/data/data_sources/remote/wallet_remote_data_source.dart';
import 'package:cambia_facile/feature/wallet/data/models/response/user_requests_response.dart';
import 'package:cambia_facile/feature/wallet/domain/entities/user_request_detail_entity.dart';
import 'package:cambia_facile/feature/wallet/domain/mapper/user_request_mapper.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import '../../../../../core/config/app_enpoint.dart';

class WalletRemoteDataSourceImpl implements WalletRemoteDataSource {
  final Dio _dioClient;

  WalletRemoteDataSourceImpl(this._dioClient);

  @override
  Future<Either<FailureEntity, List<UserRequestDetailEntity>>> getUserRequests({
    required String requestId,
  }) async {
    try {
      final response = await _dioClient.get(
        AppEndpoint.getUserRequestsEndpoint,
        queryParameters: {
          'id': requestId,
        },
      );

      if (response.data is String) {
        var jsonT = json.decode(response.data);
        return right(
          UserRequestsMapper().apply(
            UserRequestsResponse.fromJson(
              jsonT['headerData'],
            ),
          ),
        );
      }
      return left(const FailureEntity.serverFailure());
    } on DioException catch (e, stacktrace) {
      debugPrintStack(stackTrace: stacktrace);
      return left(const FailureEntity.serverFailure());
    } catch (e, stacktrace) {
      debugPrintStack(stackTrace: stacktrace);
      return left(const FailureEntity.serverFailure());
    }
  }
}
