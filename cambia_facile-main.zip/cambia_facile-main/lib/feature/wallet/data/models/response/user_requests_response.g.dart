// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_requests_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_UserRequestsResponse _$$_UserRequestsResponseFromJson(
        Map<String, dynamic> json) =>
    _$_UserRequestsResponse(
      id: json['id'] as String? ?? '-',
      creationDate: json['createdWhen'] as String? ?? '-',
      status: json['status'] as String? ?? '-',
      phone: json['phone1'] as String? ?? '-',
      surname: json['surname'] as String? ?? '-',
      name: json['name'] as String? ?? '-',
      productsIds: json['productsIds'] as String? ?? '-',
      productCounter: json['productsCount'] as String? ?? '-',
    );

Map<String, dynamic> _$$_UserRequestsResponseToJson(
        _$_UserRequestsResponse instance) =>
    <String, dynamic>{
      'id': instance.id,
      'createdWhen': instance.creationDate,
      'status': instance.status,
      'phone1': instance.phone,
      'surname': instance.surname,
      'name': instance.name,
      'productsIds': instance.productsIds,
      'productsCount': instance.productCounter,
    };
