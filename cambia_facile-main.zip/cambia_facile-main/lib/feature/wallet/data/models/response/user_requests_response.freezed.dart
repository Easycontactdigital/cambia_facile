// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_requests_response.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

UserRequestsResponse _$UserRequestsResponseFromJson(Map<String, dynamic> json) {
  return _UserRequestsResponse.fromJson(json);
}

/// @nodoc
mixin _$UserRequestsResponse {
  @JsonKey(name: 'id')
  String get id => throw _privateConstructorUsedError;
  @JsonKey(name: 'createdWhen')
  String get creationDate => throw _privateConstructorUsedError;
  @JsonKey(name: 'status')
  String get status => throw _privateConstructorUsedError;
  @JsonKey(name: 'phone1')
  String get phone => throw _privateConstructorUsedError;
  @JsonKey(name: 'surname')
  String get surname => throw _privateConstructorUsedError;
  @JsonKey(name: 'name')
  String get name => throw _privateConstructorUsedError;
  @JsonKey(name: 'productsIds')
  String get productsIds => throw _privateConstructorUsedError;
  @JsonKey(name: 'productsCount')
  String get productCounter => throw _privateConstructorUsedError;

  Map<String, dynamic> toJson() => throw _privateConstructorUsedError;
  @JsonKey(ignore: true)
  $UserRequestsResponseCopyWith<UserRequestsResponse> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserRequestsResponseCopyWith<$Res> {
  factory $UserRequestsResponseCopyWith(UserRequestsResponse value,
          $Res Function(UserRequestsResponse) then) =
      _$UserRequestsResponseCopyWithImpl<$Res, UserRequestsResponse>;
  @useResult
  $Res call(
      {@JsonKey(name: 'id') String id,
      @JsonKey(name: 'createdWhen') String creationDate,
      @JsonKey(name: 'status') String status,
      @JsonKey(name: 'phone1') String phone,
      @JsonKey(name: 'surname') String surname,
      @JsonKey(name: 'name') String name,
      @JsonKey(name: 'productsIds') String productsIds,
      @JsonKey(name: 'productsCount') String productCounter});
}

/// @nodoc
class _$UserRequestsResponseCopyWithImpl<$Res,
        $Val extends UserRequestsResponse>
    implements $UserRequestsResponseCopyWith<$Res> {
  _$UserRequestsResponseCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? creationDate = null,
    Object? status = null,
    Object? phone = null,
    Object? surname = null,
    Object? name = null,
    Object? productsIds = null,
    Object? productCounter = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      creationDate: null == creationDate
          ? _value.creationDate
          : creationDate // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      surname: null == surname
          ? _value.surname
          : surname // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      productsIds: null == productsIds
          ? _value.productsIds
          : productsIds // ignore: cast_nullable_to_non_nullable
              as String,
      productCounter: null == productCounter
          ? _value.productCounter
          : productCounter // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_UserRequestsResponseCopyWith<$Res>
    implements $UserRequestsResponseCopyWith<$Res> {
  factory _$$_UserRequestsResponseCopyWith(_$_UserRequestsResponse value,
          $Res Function(_$_UserRequestsResponse) then) =
      __$$_UserRequestsResponseCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {@JsonKey(name: 'id') String id,
      @JsonKey(name: 'createdWhen') String creationDate,
      @JsonKey(name: 'status') String status,
      @JsonKey(name: 'phone1') String phone,
      @JsonKey(name: 'surname') String surname,
      @JsonKey(name: 'name') String name,
      @JsonKey(name: 'productsIds') String productsIds,
      @JsonKey(name: 'productsCount') String productCounter});
}

/// @nodoc
class __$$_UserRequestsResponseCopyWithImpl<$Res>
    extends _$UserRequestsResponseCopyWithImpl<$Res, _$_UserRequestsResponse>
    implements _$$_UserRequestsResponseCopyWith<$Res> {
  __$$_UserRequestsResponseCopyWithImpl(_$_UserRequestsResponse _value,
      $Res Function(_$_UserRequestsResponse) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? creationDate = null,
    Object? status = null,
    Object? phone = null,
    Object? surname = null,
    Object? name = null,
    Object? productsIds = null,
    Object? productCounter = null,
  }) {
    return _then(_$_UserRequestsResponse(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      creationDate: null == creationDate
          ? _value.creationDate
          : creationDate // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      surname: null == surname
          ? _value.surname
          : surname // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      productsIds: null == productsIds
          ? _value.productsIds
          : productsIds // ignore: cast_nullable_to_non_nullable
              as String,
      productCounter: null == productCounter
          ? _value.productCounter
          : productCounter // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
@JsonSerializable()
class _$_UserRequestsResponse implements _UserRequestsResponse {
  const _$_UserRequestsResponse(
      {@JsonKey(name: 'id') this.id = '-',
      @JsonKey(name: 'createdWhen') this.creationDate = '-',
      @JsonKey(name: 'status') this.status = '-',
      @JsonKey(name: 'phone1') this.phone = '-',
      @JsonKey(name: 'surname') this.surname = '-',
      @JsonKey(name: 'name') this.name = '-',
      @JsonKey(name: 'productsIds') this.productsIds = '-',
      @JsonKey(name: 'productsCount') this.productCounter = '-'});

  factory _$_UserRequestsResponse.fromJson(Map<String, dynamic> json) =>
      _$$_UserRequestsResponseFromJson(json);

  @override
  @JsonKey(name: 'id')
  final String id;
  @override
  @JsonKey(name: 'createdWhen')
  final String creationDate;
  @override
  @JsonKey(name: 'status')
  final String status;
  @override
  @JsonKey(name: 'phone1')
  final String phone;
  @override
  @JsonKey(name: 'surname')
  final String surname;
  @override
  @JsonKey(name: 'name')
  final String name;
  @override
  @JsonKey(name: 'productsIds')
  final String productsIds;
  @override
  @JsonKey(name: 'productsCount')
  final String productCounter;

  @override
  String toString() {
    return 'UserRequestsResponse(id: $id, creationDate: $creationDate, status: $status, phone: $phone, surname: $surname, name: $name, productsIds: $productsIds, productCounter: $productCounter)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_UserRequestsResponse &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.creationDate, creationDate) ||
                other.creationDate == creationDate) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.surname, surname) || other.surname == surname) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.productsIds, productsIds) ||
                other.productsIds == productsIds) &&
            (identical(other.productCounter, productCounter) ||
                other.productCounter == productCounter));
  }

  @JsonKey(ignore: true)
  @override
  int get hashCode => Object.hash(runtimeType, id, creationDate, status, phone,
      surname, name, productsIds, productCounter);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_UserRequestsResponseCopyWith<_$_UserRequestsResponse> get copyWith =>
      __$$_UserRequestsResponseCopyWithImpl<_$_UserRequestsResponse>(
          this, _$identity);

  @override
  Map<String, dynamic> toJson() {
    return _$$_UserRequestsResponseToJson(
      this,
    );
  }
}

abstract class _UserRequestsResponse implements UserRequestsResponse {
  const factory _UserRequestsResponse(
          {@JsonKey(name: 'id') final String id,
          @JsonKey(name: 'createdWhen') final String creationDate,
          @JsonKey(name: 'status') final String status,
          @JsonKey(name: 'phone1') final String phone,
          @JsonKey(name: 'surname') final String surname,
          @JsonKey(name: 'name') final String name,
          @JsonKey(name: 'productsIds') final String productsIds,
          @JsonKey(name: 'productsCount') final String productCounter}) =
      _$_UserRequestsResponse;

  factory _UserRequestsResponse.fromJson(Map<String, dynamic> json) =
      _$_UserRequestsResponse.fromJson;

  @override
  @JsonKey(name: 'id')
  String get id;
  @override
  @JsonKey(name: 'createdWhen')
  String get creationDate;
  @override
  @JsonKey(name: 'status')
  String get status;
  @override
  @JsonKey(name: 'phone1')
  String get phone;
  @override
  @JsonKey(name: 'surname')
  String get surname;
  @override
  @JsonKey(name: 'name')
  String get name;
  @override
  @JsonKey(name: 'productsIds')
  String get productsIds;
  @override
  @JsonKey(name: 'productsCount')
  String get productCounter;
  @override
  @JsonKey(ignore: true)
  _$$_UserRequestsResponseCopyWith<_$_UserRequestsResponse> get copyWith =>
      throw _privateConstructorUsedError;
}
