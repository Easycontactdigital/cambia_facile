import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_requests_response.freezed.dart';
part 'user_requests_response.g.dart';

@freezed
class UserRequestsResponse with _$UserRequestsResponse {
  const factory UserRequestsResponse({
    @JsonKey(name: 'id') @Default('-') String id,
    @JsonKey(name: 'createdWhen') @Default('-') String creationDate,
    @JsonKey(name: 'status') @Default('-') String status,
    @JsonKey(name: 'phone1') @Default('-') String phone,
    @JsonKey(name: 'surname') @Default('-') String surname,
    @JsonKey(name: 'name') @Default('-') String name,
    @JsonKey(name: 'productsIds') @Default('-') String productsIds,
    @JsonKey(name: 'productsCount') @Default('-') String productCounter,
  }) = _UserRequestsResponse;

  factory UserRequestsResponse.fromJson(Map<String, dynamic> json) =>
      _$UserRequestsResponseFromJson(json);
}
