import 'package:cambia_facile/core/domain/use_cases/use_case.dart';
import 'package:cambia_facile/core/utils/errors/failures.dart';
import 'package:cambia_facile/feature/wallet/domain/entities/user_request_detail_entity.dart';
import 'package:cambia_facile/feature/wallet/domain/repositories/wallet_repository.dart';
import 'package:dartz/dartz.dart';

class GetUserRequestsUseCase
    implements
        UseCase<Either<FailureEntity, List<UserRequestDetailEntity>>, String> {
  final WalletRepository _repository;

  GetUserRequestsUseCase(this._repository);

  @override
  Future<Either<FailureEntity, List<UserRequestDetailEntity>>> call(
    String requestId,
  ) async {
    return await _repository.getUserRequests(requestId: requestId);
  }
}
