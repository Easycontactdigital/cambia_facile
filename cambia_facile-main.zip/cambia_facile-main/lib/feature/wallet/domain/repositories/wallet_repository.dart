import 'package:cambia_facile/core/utils/errors/failures.dart';
import 'package:cambia_facile/feature/wallet/domain/entities/user_request_detail_entity.dart';
import 'package:dartz/dartz.dart';

abstract class WalletRepository {
  Future<Either<FailureEntity, List<UserRequestDetailEntity>>> getUserRequests({
    required String requestId,
  });
}
