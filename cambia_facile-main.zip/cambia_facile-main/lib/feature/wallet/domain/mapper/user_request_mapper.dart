import 'package:cambia_facile/core/config/app_constants.dart';
import 'package:cambia_facile/core/domain/mapper/mapper.dart';
import 'package:cambia_facile/feature/wallet/data/models/response/user_requests_response.dart';
import 'package:cambia_facile/feature/wallet/domain/entities/user_request_detail_entity.dart';

class UserRequestsMapper
    implements Mapper<UserRequestsResponse, List<UserRequestDetailEntity>> {
  @override
  List<UserRequestDetailEntity> apply(UserRequestsResponse data) {
    if (data.productsIds.contains(',')) {
      var products = data.productsIds.split(',');
      List<UserRequestDetailEntity> userRequests = [];
      for (var product in products) {
        userRequests.add(UserRequestDetailEntity(
          id: data.id,
          name: data.name,
          surname: data.surname,
          phone: data.phone,
          creationDate: data.creationDate,
          status: data.status.toUpperCase(),
          productId: _retrieveProductName(product),
        ));
      }

      return userRequests;
    }

    return [
      UserRequestDetailEntity(
        id: data.id,
        name: data.name,
        surname: data.surname,
        phone: data.phone,
        creationDate: data.creationDate,
        status: data.status.toUpperCase(),
        productId: _retrieveProductName(data.productsIds),
      ),
    ];
  }

  String _retrieveProductName(String productId) {
    if (AppConstants.productMap.containsKey(productId)) {
      return AppConstants.productMap[productId]!;
    }

    return '-';
  }
}
