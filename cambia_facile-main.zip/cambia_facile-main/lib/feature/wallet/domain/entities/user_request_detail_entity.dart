import 'package:freezed_annotation/freezed_annotation.dart';

part 'user_request_detail_entity.freezed.dart';

@freezed
class UserRequestDetailEntity with _$UserRequestDetailEntity {
  const factory UserRequestDetailEntity({
    required String id,
    required String name,
    required String surname,
    required String phone,
    required String creationDate,
    required String status,
    @Default('-') String productId,
  }) = _UserRequestDetailEntity;
}
