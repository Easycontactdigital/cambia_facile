// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_request_detail_entity.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$UserRequestDetailEntity {
  String get id => throw _privateConstructorUsedError;
  String get name => throw _privateConstructorUsedError;
  String get surname => throw _privateConstructorUsedError;
  String get phone => throw _privateConstructorUsedError;
  String get creationDate => throw _privateConstructorUsedError;
  String get status => throw _privateConstructorUsedError;
  String get productId => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $UserRequestDetailEntityCopyWith<UserRequestDetailEntity> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $UserRequestDetailEntityCopyWith<$Res> {
  factory $UserRequestDetailEntityCopyWith(UserRequestDetailEntity value,
          $Res Function(UserRequestDetailEntity) then) =
      _$UserRequestDetailEntityCopyWithImpl<$Res, UserRequestDetailEntity>;
  @useResult
  $Res call(
      {String id,
      String name,
      String surname,
      String phone,
      String creationDate,
      String status,
      String productId});
}

/// @nodoc
class _$UserRequestDetailEntityCopyWithImpl<$Res,
        $Val extends UserRequestDetailEntity>
    implements $UserRequestDetailEntityCopyWith<$Res> {
  _$UserRequestDetailEntityCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? surname = null,
    Object? phone = null,
    Object? creationDate = null,
    Object? status = null,
    Object? productId = null,
  }) {
    return _then(_value.copyWith(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      surname: null == surname
          ? _value.surname
          : surname // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      creationDate: null == creationDate
          ? _value.creationDate
          : creationDate // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$_UserRequestDetailEntityCopyWith<$Res>
    implements $UserRequestDetailEntityCopyWith<$Res> {
  factory _$$_UserRequestDetailEntityCopyWith(_$_UserRequestDetailEntity value,
          $Res Function(_$_UserRequestDetailEntity) then) =
      __$$_UserRequestDetailEntityCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {String id,
      String name,
      String surname,
      String phone,
      String creationDate,
      String status,
      String productId});
}

/// @nodoc
class __$$_UserRequestDetailEntityCopyWithImpl<$Res>
    extends _$UserRequestDetailEntityCopyWithImpl<$Res,
        _$_UserRequestDetailEntity>
    implements _$$_UserRequestDetailEntityCopyWith<$Res> {
  __$$_UserRequestDetailEntityCopyWithImpl(_$_UserRequestDetailEntity _value,
      $Res Function(_$_UserRequestDetailEntity) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? id = null,
    Object? name = null,
    Object? surname = null,
    Object? phone = null,
    Object? creationDate = null,
    Object? status = null,
    Object? productId = null,
  }) {
    return _then(_$_UserRequestDetailEntity(
      id: null == id
          ? _value.id
          : id // ignore: cast_nullable_to_non_nullable
              as String,
      name: null == name
          ? _value.name
          : name // ignore: cast_nullable_to_non_nullable
              as String,
      surname: null == surname
          ? _value.surname
          : surname // ignore: cast_nullable_to_non_nullable
              as String,
      phone: null == phone
          ? _value.phone
          : phone // ignore: cast_nullable_to_non_nullable
              as String,
      creationDate: null == creationDate
          ? _value.creationDate
          : creationDate // ignore: cast_nullable_to_non_nullable
              as String,
      status: null == status
          ? _value.status
          : status // ignore: cast_nullable_to_non_nullable
              as String,
      productId: null == productId
          ? _value.productId
          : productId // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_UserRequestDetailEntity implements _UserRequestDetailEntity {
  const _$_UserRequestDetailEntity(
      {required this.id,
      required this.name,
      required this.surname,
      required this.phone,
      required this.creationDate,
      required this.status,
      this.productId = '-'});

  @override
  final String id;
  @override
  final String name;
  @override
  final String surname;
  @override
  final String phone;
  @override
  final String creationDate;
  @override
  final String status;
  @override
  @JsonKey()
  final String productId;

  @override
  String toString() {
    return 'UserRequestDetailEntity(id: $id, name: $name, surname: $surname, phone: $phone, creationDate: $creationDate, status: $status, productId: $productId)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_UserRequestDetailEntity &&
            (identical(other.id, id) || other.id == id) &&
            (identical(other.name, name) || other.name == name) &&
            (identical(other.surname, surname) || other.surname == surname) &&
            (identical(other.phone, phone) || other.phone == phone) &&
            (identical(other.creationDate, creationDate) ||
                other.creationDate == creationDate) &&
            (identical(other.status, status) || other.status == status) &&
            (identical(other.productId, productId) ||
                other.productId == productId));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, id, name, surname, phone, creationDate, status, productId);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$_UserRequestDetailEntityCopyWith<_$_UserRequestDetailEntity>
      get copyWith =>
          __$$_UserRequestDetailEntityCopyWithImpl<_$_UserRequestDetailEntity>(
              this, _$identity);
}

abstract class _UserRequestDetailEntity implements UserRequestDetailEntity {
  const factory _UserRequestDetailEntity(
      {required final String id,
      required final String name,
      required final String surname,
      required final String phone,
      required final String creationDate,
      required final String status,
      final String productId}) = _$_UserRequestDetailEntity;

  @override
  String get id;
  @override
  String get name;
  @override
  String get surname;
  @override
  String get phone;
  @override
  String get creationDate;
  @override
  String get status;
  @override
  String get productId;
  @override
  @JsonKey(ignore: true)
  _$$_UserRequestDetailEntityCopyWith<_$_UserRequestDetailEntity>
      get copyWith => throw _privateConstructorUsedError;
}
