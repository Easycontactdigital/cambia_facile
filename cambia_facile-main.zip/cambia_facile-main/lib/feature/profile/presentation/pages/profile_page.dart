import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/core/config/app_assets.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

@RoutePage()
class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: double.infinity,
      child: LottieBuilder.asset(AppAssets.wipAnimation),
    );
  }
}
