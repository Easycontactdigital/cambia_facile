class AppAssets {
  static const String _iconsPath = 'assets/icons/';
  static const String _imagesPath = 'assets/images/';
  static const String _animationsPath = 'assets/animations/';

  ///Icons
  static const flame = '${_iconsPath}ic_flame.svg';
  static const modem = '${_iconsPath}ic_modem.svg';
  static const bulb = '${_iconsPath}ic_bulb.svg';
  static const bulbAndFlame = '${_iconsPath}ic_bulb_flame.svg';
  static const informative = '${_iconsPath}ic_informative.png';
  static const logoWithName = '${_iconsPath}ic_logo_2.png';
  static const empty = '${_iconsPath}ic_empty.png';

  ///Images
  static const enel = '${_imagesPath}enel.png';
  static const a2a = '${_imagesPath}a2a.png';
  static const acea = '${_imagesPath}acea.png';
  static const edison = '${_imagesPath}edison.png';
  static const heracomm = '${_imagesPath}heracomm.png';
  static const plentitude = '${_imagesPath}plentitude.png';
  static const iberdrola = '${_imagesPath}iberdrola.png';
  static const illumia = '${_imagesPath}illumia.png';
  static const iren = '${_imagesPath}iren.png';
  static const arubaFibra = '${_imagesPath}aruba_fibra.png';
  static const fastweb = '${_imagesPath}fastweb.png';
  static const linkem = '${_imagesPath}linkem.png';
  static const sky_wifi = '${_imagesPath}sky_wifi.png';
  static const sorgenia = '${_imagesPath}sorgenia.png';
  static const tiscali = '${_imagesPath}tiscali.png';
  static const vodafone = '${_imagesPath}vodafone.png';
  static const wind_tre = '${_imagesPath}wind_tre.png';
  static const tim = '${_imagesPath}tim.png';

  ///Animations
  static const wipAnimation = '${_animationsPath}wip_animation.json';
  static const emptyAnimation = '${_animationsPath}empty_animation.json';
}
