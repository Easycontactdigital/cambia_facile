class AppEndpoint {
  static String sendFormEndpoint =
      'https://easycontact.sidial.cloud/api.php?a=pushLeadNoDupExp&apiToken=uwO0Lf.sSeFcLaOP&workGroupId=1&owner=1&createdBy=admin&leadStatus=Nuovo&campaign=15&list=30&removeIntPrefix=1&leadExpire=2028-03-31 23:59';
  static String getUserRequestsEndpoint =
      'https://easycontact.sidial.cloud/api.php?a=getOrderDetails&&apiToken=uwO0Lf.sSeFcLaOP';
}
