import 'dart:ui';

class AppColors {
  static const Color orange = Color(0xFFE85B0E);
  static const Color blueBg = Color(0xF0ACB3FF);
  static const Color yellow = Color(0xFFffde59);
  static const Color green = Color(0xFF7ed957);
  static const Color violet = Color(0xFF5b54b6);
  static const Color lightBlue = Color(0xFF29abe2);
}
