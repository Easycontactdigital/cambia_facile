import 'package:cambia_facile/feature/home/data/data_source/remote/form_remote_data_source_impl.dart';
import 'package:cambia_facile/feature/home/data/data_source/remote/from_remote_data_source.dart';
import 'package:cambia_facile/feature/home/data/repositories/form_repository_impl.dart';
import 'package:cambia_facile/feature/home/domain/repositories/form_repository.dart';
import 'package:cambia_facile/feature/home/domain/use_cases/send_form_use_case.dart';
import 'package:cambia_facile/feature/home/presentation/manager/form/form_cubit.dart';
import 'package:cambia_facile/feature/home/presentation/manager/home_cubit.dart';
import 'package:cambia_facile/feature/wallet/data/data_sources/remote/wallet_remote_data_source.dart';
import 'package:cambia_facile/feature/wallet/data/data_sources/remote/wallet_remote_data_source_impl.dart';
import 'package:cambia_facile/feature/wallet/domain/repositories/wallet_repository.dart';
import 'package:cambia_facile/feature/wallet/domain/use_cases/get_user_requests_use_case.dart';
import 'package:cambia_facile/feature/wallet/presentation/manager/wallet_cubit.dart';
import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:pretty_dio_logger/pretty_dio_logger.dart';

import '../../../feature/wallet/data/repositories/wallet_repository_impl.dart';

final injector = GetIt.instance;

Future<void> registerDependencies() async {
  _registerNetworkClient();
  _registerDataSources();
  _registerRepositories();
  _registerUseCases();
  _registerCubit();
}

void _registerNetworkClient() {
  injector.registerLazySingleton<Dio>(() {
    var dio = Dio();
    dio.interceptors.add(PrettyDioLogger());
    return dio;
  });
}

void _registerDataSources() {
  ///FORM
  injector.registerLazySingleton<FormRemoteDataSource>(
    () => FormRemoteDataSourceImpl(injector()),
  );

  ///WALLET
  injector.registerLazySingleton<WalletRemoteDataSource>(
    () => WalletRemoteDataSourceImpl(injector()),
  );
}

void _registerRepositories() {
  ///FORM
  injector.registerLazySingleton<FormRepository>(
    () => FormRepositoryImpl(injector()),
  );

  ///WALLET
  injector.registerLazySingleton<WalletRepository>(
    () => WalletRepositoryImpl(injector()),
  );
}

void _registerUseCases() {
  ///FORM
  injector.registerLazySingleton<SendFormUseCase>(
    () => SendFormUseCase(injector()),
  );

  ///WALLET
  injector.registerLazySingleton<GetUserRequestsUseCase>(
    () => GetUserRequestsUseCase(injector()),
  );
}

void _registerCubit() {
  ///HOME
  injector.registerLazySingleton<HomeCubit>(() => HomeCubit());

  ///FORM
  injector.registerLazySingleton<FormCubit>(
    () => FormCubit(sendFormUseCase: injector()),
  );

  ///WALLET
  injector.registerLazySingleton<WalletCubit>(
    () => WalletCubit(
      getUserRequestsUseCase: injector(),
    ),
  );
}
