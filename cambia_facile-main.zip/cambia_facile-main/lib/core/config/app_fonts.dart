class AppFonts {
  static const String robotoRegular = "Roboto Regular";
  static const String robotoBlack = "Roboto Black";
  static const String robotoBold = "Roboto Bold";
  static const String robotoLight = "Roboto Light";
  static const String robotoMedium = "Roboto Medium";
  static const String robotoThin = "Roboto Thin";
}
