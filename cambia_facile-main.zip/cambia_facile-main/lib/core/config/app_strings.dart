class AppStrings {
  static List<String> powerFormExplanation = [
    'Compila il form per darci tutte le indicazioni necessarie per aiutarti nella scelta;',
    'Un consulente Cambia Facile ti aiuterà alla ricerca dell’offerta luce e gas più adatta alle tue esigenze;',
    'Una volta che avrai scelto la tua offerta, il nostro consulente ti seguirà per tutte le fasi dell’attivazione;',
    'Risparmia e goditi la nuova tariffa luce e gas.',
  ];
  static List<String> gasFormExplanation = [
    'Compila il form per darci tutte le indicazioni necessarie per aiutarti nella scelta;',
    'Un consulente Cambia Facile ti aiuterà alla ricerca dell’offerta luce e gas più adatta alle tue esigenze;',
    'Una volta che avrai scelto la tua offerta, il nostro consulente ti seguirà per tutte le fasi dell’attivazione;',
    'Risparmia e goditi la nuova tariffa luce e gas.'
  ];
  static List<String> powerAndGasFormExplanation = [
    'Compila il form per darci tutte le indicazioni necessarie per aiutarti nella scelta;',
    'Un consulente Cambia Facile ti aiuterà alla ricerca dell’offerta luce e gas più adatta alle tue esigenze;',
    'Una volta che avrai scelto la tua offerta, il nostro consulente ti seguirà per tutte le fasi dell’attivazione;',
    'Risparmia e goditi la nuova tariffa luce e gas.'
  ];
  static List<String> internetFormExplanation = [
    'Compila il form;',
    'Un consulente Cambia Facile ti contatterà per guidarti tra le offerte internet presenti;',
    'Confronterete le differenze tra un’offerta e l’altra;',
    'Insieme si arriverà a trovare l’offerta più adatta alle esigenze;',
    'Il consulente ti seguirà passo a passo nell’attivazione dell’offerta;',
    'Goditi la nuova offerta internet!'
  ];

  static List<String> informativeTexts = [
    'Valutiamo la tua situazione di spesa e le tue esigenze',
    'Ti proponiamo le migliori offerte, riceverai una consulenza gratuita da un nostro consulente'
  ];

  static String mandatoryField = 'Questo campo è obbligatiorio';
  static String insertValidEmail =
      'Per favore, inserisci un indirizzo email valido';
  static String insertValidPhone =
      'Per favore, inserisci un numero di telefono valido';
  static String successMessage = 'Grazie!\nTi contatteremo al più presto';
  static String failureMessage =
      "Ops!\nQualcosa è andato storto riprova più tardi";
  static String name = 'Nome';
  static String surname = 'Cognome';
  static String email = 'Email';
  static String phoneNumber = 'Numero di telefono';
  static String send = 'Invia';
  static String proceed = 'Procedi';
  static String saveMoney = 'RISPARMIA IN UN ATTIMO';

  static String contacts = 'CONTATTI';
  static String sale = 'OFFERTE';
  static String home = 'Home';
  static String links = 'Contatti';
  static String profile = 'Profilo';
  static String wallet = 'Wallet';
  static String requstId = 'Identificativo richiesta';
  static String walletExplanation =
      'Per poter recuperare la lista delle richieste effettute, inserisci il numero identificativo della richiesta che ti è stato comunicato';
  static String search = 'Cerca';
  static String yourRequests = 'Le tue richieste';
  static String noItemsYet = 'Non sono ancora presenti richieste!';
  static String contactsInformation = 'Informazioni di contatto';
  static String requestInformation = 'Informazioni della richiesta';
  static String doYouRememberProvider = 'Ricordi il tuo fornitore?';
  static String howToSaveMoneyForEnergyAndGasTitle =
      'Come risparmiare su luce e gas';
  static String howToSaveMoneyForEnergyAndGasMessage =
      'Non esiste una tariffa luce-gas migliore in assoluto, esiste la tariffa più vantaggiosa in base alle tue necessità e al tuo stile di consumo che si riflette in bolletta. Inoltre, dopo un po’ la tua tariffa non è più competitiva perchè è nato un nuovo operatore nel mercato libero o sono state lanciate nuove offerte piu’ adatte alle tue esigenze: se compari subito tutte le offerte puoi risparmiare sul serio fino a 500€ in totale e non ti costa nulla. Perché non provarci?Noi di cambiafacile ci impegniamo a garantirti tutte le informazioni aggiornate, affidabili in modo che tu possa confrontare le offerte combinate di elettricità del servizio elettrico, gas per il riscaldamento e l’acqua calda, dei migliori gestori ed essere certo che non ti sia sfuggito nulla per valutare il tuo migliore fornitore di energia per cambiare tariffa (bioraria, trioraria o monoraria) o fare un contratto per nuovo allaccio o subentro. Fai un semplice confronto dei prezzi delle migliori offerte per le tariffe per la fornitura di luce, energia elettrica e gas dei seguenti fornitori, dedicati alla casa, alla famiglia, alle aziende e ai professionisti: Enel, Eni Luce e Gas, Iren, Illumia, Wekiwi, Acea, Gas Natural, Eviva, A2A, Sorgenia, Edison, Green Network, Heracomm, GDF Suez, Trenta, e-Light, E.ON, Aemme, AGSM, AIM, AMGA, Argos, AXO, Bluenergy, Coop, Energan, Engie, Enne, Enoi, Estra, Fintel, Gala, NWG, Omnia, Unogas, Vivigas, Optima.';
  static String bestInternetOfferTitle = 'Migliori tariffe internet casa';
  static String bestInternetOfferMessage =
      'Cambia facile confronta in pochi secondi i costi delle offerte internet casa online dei principali internet provider e trova la migliore per te in base alle tue abitudini di navigazione. Sfruttare i vantaggi del servizio di comparazione sarà intuitivo con informazioni e documenti necessari esplicitati in maniera semplice.Il servizio di comparazione mette a confronto le offerte ADSL e Fibra Ottica Casa più convenienti per le tue esigenze di molte delle principali compagnie telefoniche: Fastweb, Telecom (TIM), Vodafone e tante altre. Troviamo per te piani internet + telefono e offerte solo internet casa.';
  static String someProviders = 'Alcuni gestori';
  static String contactInformation =
      'Per qualsiasi richiesta o informazione non esitare a contattarci!';
}
