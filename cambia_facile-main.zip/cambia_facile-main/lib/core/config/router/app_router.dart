import 'package:auto_route/auto_route.dart';
import 'package:cambia_facile/feature/wallet/presentation/pages/wallet_page.dart';
import 'package:flutter/cupertino.dart';

import '../../../feature/home/domain/entities/home_page_entity.dart';
import '../../../feature/home/presentation/pages/form/form_page.dart';
import '../../../feature/home/presentation/pages/home_page.dart';
import '../../../feature/home/presentation/pages/informative/informative_page.dart';
import '../../../feature/links/presentation/pages/links_page.dart';
import '../../../feature/main/main/presentation/pages/main_page.dart';
import '../../../feature/profile/presentation/pages/profile_page.dart';

part 'app_router.gr.dart';

@AutoRouterConfig(
  replaceInRouteName: 'Page,Route',
)
class AppRouter extends _$AppRouter {
  @override
  List<AutoRoute> get routes => [
        CustomRoute(
          page: MainRoute.page,
          initial: true,
          children: [
            AutoRoute(page: HomeRoute.page),
            AutoRoute(page: LinksRoute.page),
            AutoRoute(page: ProfileRoute.page),
            AutoRoute(page: WalletRoute.page),
          ],
        ),
        CustomRoute(
          page: InformativeRoute.page,
          transitionsBuilder: TransitionsBuilders.slideLeftWithFade,
        ),
        CustomRoute(
          page: FormRoute.page,
          transitionsBuilder: TransitionsBuilders.slideLeftWithFade,
        ),
      ];
}
