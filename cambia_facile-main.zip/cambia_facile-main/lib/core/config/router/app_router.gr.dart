// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

part of 'app_router.dart';

abstract class _$AppRouter extends RootStackRouter {
  // ignore: unused_element
  _$AppRouter({super.navigatorKey});

  @override
  final Map<String, PageFactory> pagesMap = {
    FormRoute.name: (routeData) {
      final args = routeData.argsAs<FormRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: FormPage(
          key: args.key,
          title: args.title,
          explanation: args.explanation,
          offerType: args.offerType,
        ),
      );
    },
    InformativeRoute.name: (routeData) {
      final args = routeData.argsAs<InformativeRouteArgs>();
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: InformativePage(
          key: args.key,
          title: args.title,
          explanation: args.explanation,
          offerType: args.offerType,
        ),
      );
    },
    HomeRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const HomePage(),
      );
    },
    ProfileRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const ProfilePage(),
      );
    },
    LinksRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const LinksPage(),
      );
    },
    WalletRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const WalletPage(),
      );
    },
    MainRoute.name: (routeData) {
      return AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const MainPage(),
      );
    },
  };
}

/// generated route for
/// [FormPage]
class FormRoute extends PageRouteInfo<FormRouteArgs> {
  FormRoute({
    Key? key,
    required String title,
    required List<String> explanation,
    required OfferType offerType,
    List<PageRouteInfo>? children,
  }) : super(
          FormRoute.name,
          args: FormRouteArgs(
            key: key,
            title: title,
            explanation: explanation,
            offerType: offerType,
          ),
          initialChildren: children,
        );

  static const String name = 'FormRoute';

  static const PageInfo<FormRouteArgs> page = PageInfo<FormRouteArgs>(name);
}

class FormRouteArgs {
  const FormRouteArgs({
    this.key,
    required this.title,
    required this.explanation,
    required this.offerType,
  });

  final Key? key;

  final String title;

  final List<String> explanation;

  final OfferType offerType;

  @override
  String toString() {
    return 'FormRouteArgs{key: $key, title: $title, explanation: $explanation, offerType: $offerType}';
  }
}

/// generated route for
/// [InformativePage]
class InformativeRoute extends PageRouteInfo<InformativeRouteArgs> {
  InformativeRoute({
    Key? key,
    required String title,
    required List<String> explanation,
    required OfferType offerType,
    List<PageRouteInfo>? children,
  }) : super(
          InformativeRoute.name,
          args: InformativeRouteArgs(
            key: key,
            title: title,
            explanation: explanation,
            offerType: offerType,
          ),
          initialChildren: children,
        );

  static const String name = 'InformativeRoute';

  static const PageInfo<InformativeRouteArgs> page =
      PageInfo<InformativeRouteArgs>(name);
}

class InformativeRouteArgs {
  const InformativeRouteArgs({
    this.key,
    required this.title,
    required this.explanation,
    required this.offerType,
  });

  final Key? key;

  final String title;

  final List<String> explanation;

  final OfferType offerType;

  @override
  String toString() {
    return 'InformativeRouteArgs{key: $key, title: $title, explanation: $explanation, offerType: $offerType}';
  }
}

/// generated route for
/// [HomePage]
class HomeRoute extends PageRouteInfo<void> {
  const HomeRoute({List<PageRouteInfo>? children})
      : super(
          HomeRoute.name,
          initialChildren: children,
        );

  static const String name = 'HomeRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [ProfilePage]
class ProfileRoute extends PageRouteInfo<void> {
  const ProfileRoute({List<PageRouteInfo>? children})
      : super(
          ProfileRoute.name,
          initialChildren: children,
        );

  static const String name = 'ProfileRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [LinksPage]
class LinksRoute extends PageRouteInfo<void> {
  const LinksRoute({List<PageRouteInfo>? children})
      : super(
          LinksRoute.name,
          initialChildren: children,
        );

  static const String name = 'LinksRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [WalletPage]
class WalletRoute extends PageRouteInfo<void> {
  const WalletRoute({List<PageRouteInfo>? children})
      : super(
          WalletRoute.name,
          initialChildren: children,
        );

  static const String name = 'WalletRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}

/// generated route for
/// [MainPage]
class MainRoute extends PageRouteInfo<void> {
  const MainRoute({List<PageRouteInfo>? children})
      : super(
          MainRoute.name,
          initialChildren: children,
        );

  static const String name = 'MainRoute';

  static const PageInfo<void> page = PageInfo<void>(name);
}
