import 'package:cambia_facile/core/config/app_fonts.dart';
import 'package:flutter/material.dart';

import '../../config/app_colors.dart';

class ChipNumberAndTextWidget extends StatelessWidget {
  final int index;
  final String text;

  const ChipNumberAndTextWidget({
    super.key,
    required this.index,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          decoration: ShapeDecoration(
            color: AppColors.orange,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(100),
            ),
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 6,
          ),
          child: Text(
            (index + 1).toString(),
            style: const TextStyle(
              color: Colors.white,
              fontSize: 10,
              height: 0,
              fontFamily: AppFonts.robotoBold,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        const SizedBox(
          width: 8,
        ),
        Expanded(
          child: Text(
            text,
            style: const TextStyle(
              fontSize: 16,
              fontFamily: AppFonts.robotoLight,
              fontWeight: FontWeight.w300,
            ),
          ),
        ),
      ],
    );
  }
}
